import argparse
import scipy.io as sio
import numpy as np
import socket
#('myfmetadata.mat', pressure, recordingId, objectId, frame, splitId, batchId, hasValidLabel,
#                    isBalanced)  # 将最新订阅到的数据保存在.mat文件中

import time
parser = argparse.ArgumentParser(description='test')
parser.add_argument("--square", type=int,default=0,help="display a square of a given number")
args = parser.parse_args()
print(args.square**2)

data = sio.loadmat('../data/classification/myfmetadata.mat')
# a= sio.loadmat('metadata.mat')
#data2 = sio.loadmat('metadata.mat')
print(data)
object = data['objects']
objectId=data['objectId']
batches=data['batches']
pressure=data['pressure']
splits=data['splits']
print('ssssss',splits)
print(objectId)
#print('pressure:', data['pressure'])
# print('objectId:', data)
print('object:', object.shape)

#
# print('aaaaaaaaaaaaaaaaaaaaaa',batches[0])
# print(np.shape(data))
print(np.shape(pressure))
# print(np.shape(batches))
#
# socket
#
# rcv_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# rcv_client.settimeout(60)
# connect = False


# # connect socket server
# while not connect:
#     try:
#         print("xxxxxx")
#         rcv_client.connect(('192.168.100.189', 888))
#         connect = True
#         print('connect to','192.168.100.189', 888)
#     except socket.error as e:
#         print("Address-related error connecting to server: %s" % e)
#         connect = False
#         time.sleep(1)
#         continue
#     pass
